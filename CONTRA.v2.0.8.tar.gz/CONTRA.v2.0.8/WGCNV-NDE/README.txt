Use wgcnv_wrapper.py
