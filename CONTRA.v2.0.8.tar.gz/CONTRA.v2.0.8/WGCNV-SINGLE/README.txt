Variant file name:   <samp>_*.tsv
Then the variant file should have the following columns:
1.<samp>:PMCFREQ		Tumour variant frequency
2.<anotherSample>:PMCFREQ	Normal variant frequency
3.CANONICAL:			Value "YES" would indicate canonical transcript, only these will be included.

Contact CONTRA authors if this is not working for you.
